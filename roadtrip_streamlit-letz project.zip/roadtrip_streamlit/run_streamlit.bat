@echo off
title Road Trip Stop Planner - Streamlit
cd /d "%~dp0"
python --version
if errorlevel 1 (
    echo Python is not installed or is not in PATH.
    pause
    exit /b 1
)
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo Package installation failed. Check your internet connection.
    pause
    exit /b 1
)
python -m streamlit run app.py
pause
