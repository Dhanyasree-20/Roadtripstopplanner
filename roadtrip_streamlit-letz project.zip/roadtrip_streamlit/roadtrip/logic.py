"""Pure-Python business logic for the Road Trip Stop Planner.

Nothing in this module imports Streamlit, so it can be unit-tested on its own.
It is a direct port of the rules that lived in the original script.js.
"""
from __future__ import annotations

import csv
import io
import json
import math
import re
from datetime import date, datetime, timezone

CATEGORIES = ["City", "Nature", "Adventure", "Beach", "Other"]

FATIGUE_LIMIT_HOURS = 4.5
SPEED_MAX_KMH = 115
SPEED_MIN_KMH = 15
LONG_HAUL_KM = 800


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #
def fmt_num(value) -> str:
    """Print 10.0 as '10' and 4.5 as '4.5' (mirrors JavaScript number printing)."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return str(value)
    return str(int(f)) if f.is_integer() else repr(f)


def today_iso() -> str:
    return date.today().isoformat()


def now_iso() -> str:
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


def to_number(value) -> float:
    """Number(x) from JavaScript: NaN when it cannot be parsed."""
    if value is None:
        return float("nan")
    if isinstance(value, bool):
        return float(value)
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip()
    if text == "":
        return 0.0
    try:
        return float(text)
    except ValueError:
        return float("nan")


def next_id(stops: list[dict]) -> int:
    return max((int(s.get("id", 0)) for s in stops), default=0) + 1


def reindex(stops: list[dict]) -> None:
    for idx, stop in enumerate(stops):
        stop["sequence"] = idx + 1


# --------------------------------------------------------------------------- #
# Validation
# --------------------------------------------------------------------------- #
def validate_stop(stops, name, distance, time, category, notes="", current_id=None):
    """Return a dict of errors (empty when the payload is valid)."""
    errors: dict[str, str] = {}

    if not name or not isinstance(name, str):
        errors["name"] = "Destination name is required."
    else:
        clean = name.strip()
        if len(clean) < 2 or len(clean) > 60:
            errors["name"] = "Name must be between 2 and 60 characters."

    dist = to_number(distance)
    if not math.isfinite(dist) or dist < 0.1 or dist > 10000:
        errors["distance"] = "Distance must be a positive number between 0.1 and 10,000 km."

    hrs = to_number(time)
    if not math.isfinite(hrs) or hrs < 0.1 or hrs > 240:
        errors["time"] = "Travel time must be between 0.1 and 240 hours."

    if not category or category not in CATEGORIES:
        errors["category"] = "Please select a valid destination category."

    if name and isinstance(name, str) and "name" not in errors:
        lowered = name.strip().lower()
        for s in stops:
            if s["name"].lower() == lowered and str(s["id"]) != str(current_id):
                errors["duplicate"] = f"Destination '{name}' already exists in your itinerary."
                break
    return errors


# --------------------------------------------------------------------------- #
# Threshold evaluation
# --------------------------------------------------------------------------- #
def evaluate_stop(stop: dict) -> dict:
    speed = stop["distance"] / stop["time"]
    flags = []

    if stop["time"] > FATIGUE_LIMIT_HOURS:
        flags.append({
            "type": "FATIGUE", "severity": "warning",
            "title": "Driver Fatigue Warning",
            "desc": f"Driving duration of {fmt_num(stop['time'])}h exceeds the 4.5h safety limit. Schedule a 30m break.",
            "recommendation": "Take a mandatory rest break or switch co-drivers.",
        })

    if speed > SPEED_MAX_KMH:
        flags.append({
            "type": "SPEED_HIGH", "severity": "critical",
            "title": "Critical Speed Anomaly",
            "desc": f"Implied speed is {speed:.1f} km/h. Exceeds standard highway safety maximum.",
            "recommendation": "Re-check estimated distance and travel time for realistic pacing.",
        })
    elif speed < SPEED_MIN_KMH:
        flags.append({
            "type": "SPEED_LOW", "severity": "warning",
            "title": "Severe Congestion / Low Pace",
            "desc": f"Implied pace of {speed:.1f} km/h indicates extreme crawl or mountain terrain.",
            "recommendation": "Verify whether road repairs or dense urban choke-points exist.",
        })

    if stop["distance"] > LONG_HAUL_KM:
        flags.append({
            "type": "EXTREME_DISTANCE", "severity": "warning",
            "title": "Long-Haul Endurance Leg",
            "desc": f"Single leg distance of {fmt_num(stop['distance'])} km requires continuous refueling stops.",
            "recommendation": "Plan intermediate fuel stops and overnight accommodation.",
        })

    return {
        "speed": speed,
        "flags": flags,
        "has_warnings": bool(flags),
        "has_critical": any(f["severity"] == "critical" for f in flags),
    }


def pace_preview(distance, time):
    """Live 'Calculated Pace' text for the add/edit dialog -> (text, colour)."""
    try:
        d, t = float(distance), float(time)
    except (TypeError, ValueError):
        return "-- km/h", "gray"
    if d > 0 and t > 0:
        spd = d / t
        if spd > SPEED_MAX_KMH:
            return f"{spd:.1f} km/h • Speeding Risk (>115 km/h)", "red"
        if spd < SPEED_MIN_KMH:
            return f"{spd:.1f} km/h • Low Pace / Congestion (<15 km/h)", "orange"
        return f"{spd:.1f} km/h • Healthy Pace", "green"
    return "-- km/h", "gray"


# --------------------------------------------------------------------------- #
# Route arrangement
# --------------------------------------------------------------------------- #
def optimize_order(stops: list[dict]) -> list[dict]:
    """Nearest-neighbour heuristic exactly as in the original app."""
    unvisited = list(stops)
    optimized = [unvisited.pop(0)]
    while unvisited:
        current = optimized[-1]
        best_idx, best = 0, math.inf
        for i, cand in enumerate(unvisited):
            diff = abs(current["distance"] - cand["distance"]) + cand["time"] * 15
            if diff < best:
                best, best_idx = diff, i
        optimized.append(unvisited.pop(best_idx))
    return optimized


def format_clock(minutes: int) -> str:
    h = (minutes // 60) % 24
    m = minutes % 60
    period = "PM" if h >= 12 else "AM"
    display = 12 if h % 12 == 0 else h % 12
    return f"{display:02d}:{m:02d} {period}"


def compute_timeline(stops: list[dict], start: str = "08:00") -> list[dict]:
    try:
        sh, sm = (int(x) for x in start.split(":")[:2])
    except ValueError:
        sh, sm = 8, 0
    clock = (sh or 8) * 60 + (sm or 0)
    cum_km = cum_h = 0.0
    out = []
    for stop in stops:
        cum_km += stop["distance"]
        cum_h += stop["time"]
        arrival = clock + round(stop["time"] * 60)
        rest = 30 if stop["time"] > FATIGUE_LIMIT_HOURS else 0
        item = dict(stop)
        item.update(
            cum_km=cum_km, cum_h=cum_h,
            departure=format_clock(clock), arrival=format_clock(arrival),
            eval=evaluate_stop(stop),
        )
        out.append(item)
        clock = arrival + rest
    return out


# --------------------------------------------------------------------------- #
# Executive summary
# --------------------------------------------------------------------------- #
def compute_summary(stops: list[dict]) -> dict:
    n = len(stops)
    cats = {c: 0 for c in CATEGORIES}
    if n == 0:
        return dict(total_stops=0, total_km=0.0, miles=0.0, time_fmt="0h 0m", total_h=0.0,
                    avg_km=0.0, avg_speed=0.0, warning_count=0, warnings=[], fuel=0.0,
                    carbon=0.0, categories=cats)
    total_km = sum(s["distance"] for s in stops)
    total_h = sum(s["time"] for s in stops)
    fuel = total_km / 100 * 8.5
    minutes = round(total_h * 60)
    warnings = []
    for s in stops:
        cats[s["category"]] = cats.get(s["category"], 0) + 1
        for f in evaluate_stop(s)["flags"]:
            warnings.append({**f, "stop_id": s["id"], "stop_seq": s["sequence"], "stop_name": s["name"]})
    return dict(
        total_stops=n, total_km=total_km, miles=total_km * 0.621371,
        time_fmt=f"{minutes // 60}h {minutes % 60}m", total_h=total_h,
        avg_km=total_km / n, avg_speed=total_km / total_h if total_h > 0 else 0.0,
        warning_count=len(warnings), warnings=warnings, fuel=fuel, carbon=fuel * 2.3,
        categories=cats,
    )


# --------------------------------------------------------------------------- #
# Exports  -> (filename, bytes, mime)
# --------------------------------------------------------------------------- #
def _date_slug() -> str:
    return date.today().strftime("%Y%m%d")


def _safe_csv_cell(val) -> str:
    text = "" if val is None else str(val)
    if re.match(r"^\s*[=+\-@]", text):
        text = "'" + text
    return '"' + text.replace('"', '""') + '"'


def build_csv(stops):
    headers = ["Sequence_Number", "Destination_Name", "Distance_KM", "Travel_Time_Hours",
               "Implied_Speed_KMH", "Category", "Travel_Notes", "Date_Logged", "Threshold_Alerts"]
    rows = []
    for s in stops:
        ev = evaluate_stop(s)
        alerts = " | ".join(f["title"] for f in ev["flags"]) or "NORMAL"
        rows.append([s["sequence"], s["name"], f"{s['distance']:.1f}", f"{s['time']:.1f}",
                     f"{ev['speed']:.1f}", s["category"], s["notes"], s["date"], alerts])
    body = "\r\n".join(",".join(_safe_csv_cell(c) for c in r) for r in [headers, *rows])
    return (f"RoadTrip_Itinerary_Report_{_date_slug()}.csv",
            body.encode("utf-8-sig"), "text/csv")


def build_markdown(stops, user: str):
    s = compute_summary(stops)
    md = "# Road Trip Stop Planner: Executive Itinerary Audit Report\n\n"
    md += "**Project:** #60 Road Trip Stop Planner | **Domain:** Travel & Transport\n"
    md += f"**Export Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} (Local Time)\n"
    md += f"**Authentication Lead:** {user}\n\n"
    md += "## 1. Executive Summary Telemetry\n\n| Metric Indicator | Computed Value |\n| :--- | :--- |\n"
    md += f"| **Total Stops Arranged** | {s['total_stops']} |\n"
    md += f"| **Total Route Distance** | {s['total_km']:.1f} km (~ {s['miles']:.1f} miles) |\n"
    md += f"| **Total Estimated Driving Time** | {s['time_fmt']} ({s['total_h']:.1f} hours) |\n"
    md += f"| **Average Leg Distance** | {s['avg_km']:.1f} km |\n"
    md += f"| **Average Implied Pace** | {s['avg_speed']:.1f} km/h |\n"
    md += f"| **Total Active Threshold Alerts** | {s['warning_count']} flags |\n"
    md += f"| **Estimated Fuel Consumption** | {s['fuel']:.1f} Liters |\n"
    md += f"| **Estimated Carbon Footprint** | {s['carbon']:.1f} kg CO2 |\n\n"
    md += "## 2. Sequentially Arranged Itinerary\n\n"
    md += "| Seq | Destination | Category | Leg KM | Leg Time | Speed | Status Alerts | Waypoint Notes |\n"
    md += "| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |\n"
    for it in compute_timeline(stops):
        ev = it["eval"]
        alert = "<br>".join(f"⚠️ {f['title']}" for f in ev["flags"]) if ev["flags"] else "✅ Normal"
        md += (f"| #{it['sequence']} | **{it['name']}** | {it['category']} | {it['distance']:.1f} km | "
               f"{it['time']:.1f}h | {ev['speed']:.1f} km/h | {alert} | {it['notes'] or '-'} |\n")
    md += "\n## 3. Threshold Warning & Safety Analysis\n\n"
    if not s["warnings"]:
        md += "*No critical limit breaches or driver fatigue thresholds were violated in this itinerary. Safe travels!*\n"
    else:
        md += f"The system detected **{len(s['warnings'])}** operational or safety flags:\n\n"
        for i, w in enumerate(s["warnings"], 1):
            md += f"{i}. **[{w['severity'].upper()}] Stop #{w['stop_seq']} ({w['stop_name']})**: {w['desc']}\n"
            md += f"   - *Safety Recommendation:* {w['recommendation']}\n"
    md += "\n---\n*Report generated deterministically by Road Trip Stop Planner (LocalImpact Challenge).*"
    return (f"RoadTrip_Executive_Report_{_date_slug()}.md", md.encode("utf-8"), "text/markdown")


def build_audit_log(logs, user: str):
    bar = "=" * 79
    text = f"{bar}\n ROAD TRIP STOP PLANNER - SYSTEM AUDIT LOG\n Generated: {now_iso()}\n"
    text += f" User: {user}\n Total Action Records: {len(logs)}\n{bar}\n\n"
    for l in logs:
        text += f"[{l['timestamp']}] [{l['action']:<20}] {l['details']}\n"
    return (f"RoadTrip_Audit_Trail_{_date_slug()}.log", text.encode("utf-8"), "text/plain")


def build_json(stops, user: str):
    s = compute_summary(stops)
    payload = {
        "project": "Project #60: Road Trip Stop Planner",
        "exportTimestamp": now_iso(),
        "leadUser": user,
        "telemetry": {
            "totalStops": s["total_stops"], "totalDistanceKm": s["total_km"],
            "totalHours": s["total_h"], "averageSpeedKmh": s["avg_speed"],
            "warningCount": s["warning_count"],
        },
        "records": stops,
    }
    return (f"RoadTrip_StateBackup_{_date_slug()}.json",
            json.dumps(payload, indent=2).encode("utf-8"), "application/json")


# --------------------------------------------------------------------------- #
# Bulk ingestion
# --------------------------------------------------------------------------- #
def _first(d: dict, keys, default=""):
    for k in keys:
        v = d.get(k)
        if v not in (None, "", 0, False):
            return v
    return default


def parse_csv_rows(text: str) -> list[dict]:
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) < 2:
        return []
    reader = csv.reader(lines)
    headers = [h.strip().strip("\"'") for h in next(reader)]
    rows = []
    for i, cells in enumerate(reader, start=2):
        if not cells:
            continue
        data = {h: (cells[idx].strip() if idx < len(cells) else "") for idx, h in enumerate(headers)}
        rows.append({"row": i, "data": data})
    return rows


def parse_json_rows(text: str) -> list[dict]:
    parsed = json.loads(text)  # raises ValueError on invalid JSON
    items = parsed if isinstance(parsed, list) else (parsed.get("records") or [])
    rows = []
    for idx, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            item = {}
        def pick(*keys, default=""):
            for k in keys:
                if item.get(k) is not None:
                    return item[k]
            return default
        rows.append({"row": idx, "data": {
            "Destination": item.get("name") or item.get("Destination") or "",
            "Distance_KM": pick("distance", "Distance_KM"),
            "Travel_Time_Hours": pick("time", "Travel_Time_Hours"),
            "Category": item.get("category") or item.get("Category") or "Other",
            "Notes": item.get("notes") or item.get("Notes") or "",
            "Date": item.get("date") or item.get("Date") or "",
        }})
    return rows


def ingest(existing: list[dict], content: str, is_json: bool, replace: bool):
    """Validate every row. Returns (new_stop_list | None, audit_rows, pass_n, fail_n, error)."""
    try:
        candidates = parse_json_rows(content) if is_json else parse_csv_rows(content)
    except ValueError:
        return None, [], 0, 0, "JSON Parse Error: Invalid format."
    if not candidates:
        return None, [], 0, 0, "No readable data rows found in the provided file."

    baseline = [] if replace else list(existing)
    accepted: list[dict] = []
    audit = []
    start_id = next_id(baseline)

    for cand in candidates:
        d = cand["data"]
        name = _first(d, ["Destination", "destination", "Name", "name"])
        dist = _first(d, ["Distance_KM", "distance", "Distance"])
        hrs = _first(d, ["Travel_Time_Hours", "travel_time", "time", "Time"])
        cat = _first(d, ["Category", "category"], "Other")
        notes = _first(d, ["Notes", "notes", "Travel_Notes"])
        dated = _first(d, ["Date", "date"], today_iso())

        errors = validate_stop(baseline + accepted, name, dist, hrs, cat, notes)
        if not errors:
            accepted.append({
                "id": start_id + len(accepted), "sequence": 0, "name": name.strip(),
                "distance": float(dist), "time": float(hrs), "category": cat,
                "notes": str(notes).strip(), "date": dated,
            })
            audit.append({"row": cand["row"], "name": str(name), "ok": True,
                          "note": f"Valid stop ({dist} km, {hrs}h, {cat})"})
        else:
            audit.append({"row": cand["row"], "name": str(name) or "[Blank]", "ok": False,
                          "note": "; ".join(errors.values())})

    passed = len(accepted)
    failed = len(audit) - passed
    if not accepted:
        return None, audit, passed, failed, None
    new_list = accepted if replace else baseline + accepted
    reindex(new_list)
    return new_list, audit, passed, failed, None
