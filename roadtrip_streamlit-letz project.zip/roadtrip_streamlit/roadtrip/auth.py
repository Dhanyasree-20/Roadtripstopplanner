"""Login screen (native Streamlit widgets only)."""
from __future__ import annotations

import re

import streamlit as st

from . import state
from .logic import now_iso
from .ui import stretch

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
USER_RE = re.compile(r"^[a-zA-Z0-9_\-.]{3,30}$")
DEMO_EMAIL, DEMO_PASSWORD = "explorer@roadtrip.com", "roadtrip2026"


def valid_identifier(value: str) -> bool:
    return len(value) >= 3 and bool(EMAIL_RE.match(value) or USER_RE.match(value))


def valid_password(value: str) -> bool:
    return len(value) >= 4


def _login(identifier: str) -> None:
    username = identifier.split("@")[0] if "@" in identifier else identifier
    st.session_state.user = {
        "username": username[:1].upper() + username[1:],
        "email": identifier if "@" in identifier else identifier + "@roadtrip.local",
        "role": "Lead Expedition Planner",
        "login_time": now_iso(),
    }
    st.session_state.page = "dashboard"
    state.log("LOGIN", f"User '{identifier}' signed in.")
    state.toast("Authentication verified. Loading Stop Planner...", "success")


def _submit() -> None:
    ss = st.session_state
    ss.login_attempted = True
    email = ss.get("login_email", "").strip()
    password = ss.get("login_password", "")
    if valid_identifier(email) and valid_password(password):
        _login(email)


def _demo() -> None:
    _login(DEMO_EMAIL)


def login_view() -> None:
    ss = st.session_state
    attempted = ss.get("login_attempted", False)

    with st.container(border=True):
        left, right = st.columns([1.15, 1], gap="large")

        # ---- brand panel -------------------------------------------------- #
        with left:
            st.markdown("#### :blue-background[ **R** ] RoadTrip:blue[.]")
            st.caption("PROJECT #60 • LOCALIMPACT")
            st.markdown(":blue-badge[:material/star: Travel & Transport Hackathon Suite]")
            st.markdown("# Every milestone  \n# needs an :blue[intelligent route.]")
            st.write(":gray[Arrange stops, optimize multi-leg distances, monitor driver fatigue thresholds, "
                     "and export multi-format audit logs with zero backend dependencies.]")
            for icon, title, text in [
                ("shuffle", "Dynamic Stop Arrangement Engine",
                 "Reorder itinerary stops, compute leg & cumulative travel times"),
                ("warning", "Defensive Validation & Threshold Warnings",
                 "Speed limit anomaly alerts, driver fatigue flags, and bounds checks"),
                ("list", "Multi-Format Export & Bulk Ingestion",
                 "CSV, Markdown, Plain-Text Audit Logs, and JSON with row-by-row error logs"),
            ]:
                with st.container(border=True):
                    c = st.columns([1, 9], vertical_alignment="center")
                    c[0].markdown(f":blue[:material/{icon}:]")
                    c[1].markdown(f"**{title}**")
                    c[1].caption(text)
            st.divider()
            f = st.columns(2)
            f[0].caption("Road Trip Stop Planner © 2026")
            f[1].caption("Standard Web Compliance")

        # ---- sign-in panel ------------------------------------------------ #
        with right:
            st.caption(":blue[**SECURE CLIENT ACCESS**]")
            st.markdown("## Welcome to RoadTrip")
            st.caption("Sign in to manage itineraries, analyze routes, and export reports.")

            with st.container(border=True):
                d = st.columns([3, 1.5], vertical_alignment="center")
                d[0].markdown(f"**Demo Account:** {DEMO_EMAIL}")
                d[0].caption(f"Password: `{DEMO_PASSWORD}`")
                d[1].button("One-Click Demo →", type="primary", key="demo_btn", on_click=_demo,
                            **stretch(st.button))

            email = ss.get("login_email", "").strip()
            password = ss.get("login_password", "")
            email_bad = bool(email) and not valid_identifier(email) or (attempted and not valid_identifier(email))
            pass_bad = bool(password) and not valid_password(password) or (attempted and not valid_password(password))

            if attempted and (email_bad or pass_bad):
                st.error("Please correct the highlighted inputs before proceeding.")

            st.text_input("Email or Username", placeholder="e.g. explorer@roadtrip.com",
                          icon=":material/mail:", key="login_email")
            if email_bad:
                st.caption(":red[Valid email required]")
            st.text_input("Password", type="password", placeholder="Enter your access key",
                          icon=":material/lock:", key="login_password")
            if pass_bad:
                st.caption(":red[Min 4 characters]")

            r = st.columns([1, 1], vertical_alignment="center")
            r[0].checkbox("Remember session", value=True, key="login_remember")
            r[1].caption("🔐 :blue[Client-Side Auth]")

            st.button("Authenticate & Launch Itinerary  →", type="primary", key="login_btn",
                      on_click=_submit, **stretch(st.button))
            st.caption("Protected client session • :green[Offline Capable]")
