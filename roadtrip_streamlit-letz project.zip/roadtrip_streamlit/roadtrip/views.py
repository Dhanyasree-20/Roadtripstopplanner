"""The five application pages plus the shared sidebar / top bar."""
from __future__ import annotations

import math
from datetime import time as dtime

import streamlit as st

from . import dialogs
from . import logic as L
from . import state
from .ui import (badge, card_title, cat_badge, esc, header_row, stat_card, status_badge, stretch)

BTN = stretch(st.button)


# --------------------------------------------------------------------------- #
# Chrome: sidebar, top bar, alert banner
# --------------------------------------------------------------------------- #
def sidebar(summary: dict) -> None:
    ss = st.session_state
    with st.sidebar:
        st.markdown("#### :blue-background[ **R** ] RoadTrip:blue[.]")
        st.caption("PROJECT #60 • LOCALIMPACT")
        st.divider()
        st.caption("**OPERATIONS**")
        counts = {"sequencer": summary["total_stops"], "inspector": summary["warning_count"]}
        icons = {"dashboard": "dashboard", "sequencer": "shuffle", "directory": "list",
                 "inspector": "warning", "terminal": "terminal"}
        for key, (label, _) in state.PAGES.items():
            text = f"{label}   ·   {counts[key]}" if key in counts else label
            st.button(text, key=f"nav_{key}", icon=f":material/{icons[key]}:",
                      type="primary" if ss.page == key else "tertiary",
                      on_click=state.goto, args=(key,), **BTN)
        st.divider()
        with st.container(border=True):
            name = state.username()
            c1, c2 = st.columns([1, 4], vertical_alignment="center")
            c1.markdown(f":violet-background[ **{name[:1].upper()}** ]")
            c2.markdown(f"**{esc(name)}**")
            c2.caption("Expedition Lead")
            if st.button("Sign out", key="logout", icon=":material/logout:", **BTN):
                ss.user = None
                ss.page = "dashboard"
                st.rerun()


def topbar() -> None:
    ss = st.session_state
    title = state.PAGES[ss.page]
    left, b1, b2, b3, b4 = st.columns([4.2, 1.3, 1.6, 1.5, 1.1], vertical_alignment="center")
    left.caption(f":blue[**ROAD TRIP PLANNER / {title[1].upper()}**]")
    left.markdown(f"## {title[1]}")
    if b1.button("CLI Console", icon=":material/terminal:", key="top_cli", **BTN):
        state.goto("terminal")
        st.rerun()
    if b2.button("Ingest CSV / JSON", icon=":material/download:", key="top_ingest", **BTN):
        dialogs.open_import()
    if b3.button("Export Reports", icon=":material/ios_share:", key="top_export", **BTN):
        dialogs.export_dialog()
    if b4.button("Add Stop", icon=":material/add:", type="primary", key="top_add", **BTN):
        dialogs.add_stop_dialog()


def alert_banner(summary: dict) -> None:
    n = summary["warning_count"]
    if not n:
        return
    c1, c2 = st.columns([6, 1.3], vertical_alignment="center")
    c1.warning(f"{n} Threshold Alert{'s' if n > 1 else ''} detected in route itinerary "
               f"(Fatigue, Pace, or Long Haul).", icon=":material/warning:")
    c2.button("Inspect Warnings →", key="banner_inspect", on_click=state.goto,
              args=("inspector",), **BTN)


# --------------------------------------------------------------------------- #
# 1. Executive summary
# --------------------------------------------------------------------------- #
def dashboard(summary: dict) -> None:
    stops = st.session_state.stops

    with st.container(border=True):
        c1, c2 = st.columns([3, 1.5], vertical_alignment="center")
        c1.markdown("### Autonomous Route Overview")
        c1.caption("Real-time route analytics, computed cumulative driving times, and automated "
                   "defensive threshold checks for Project #60.")
        b1, b2 = c2.columns(2)
        b1.button("Arrange Stops →", key="dash_arrange", on_click=state.goto, args=("sequencer",), **BTN)
        fname, data, mime = state.build_export("csv")
        b2.download_button("Quick CSV ↓", data=data, file_name=fname, mime=mime, key="dash_csv",
                           on_click=state.record_export, args=("csv",),
                           **stretch(st.download_button))

    avg = summary["avg_speed"]
    pace_hint = "Healthy pace" if L.SPEED_MIN_KMH <= avg <= L.SPEED_MAX_KMH else "Check pacing assumptions"
    row1 = st.columns(4)
    with row1[0]:
        stat_card("Total Stops", str(summary["total_stops"]), "", "Planned destinations in queue", "location_on")
    with row1[1]:
        stat_card("Total Distance", f"{summary['total_km']:.1f}", "km",
                  f"~ {summary['miles']:.1f} miles", "shuffle")
    with row1[2]:
        stat_card("Total Driving Time", summary["time_fmt"], "", "Includes safety stops", "schedule")
    with row1[3]:
        stat_card("Average Leg Distance", f"{summary['avg_km']:.1f}", "km", "Per stop milestone", "diamond")
    row2 = st.columns(4)
    with row2[0]:
        stat_card("Average Speed", f"{avg:.1f}", "km/h", pace_hint, "bolt")
    with row2[1]:
        stat_card("Safety Alerts", str(summary["warning_count"]), "", "Fatigue & speed flags", "warning")

    left, right = st.columns([1.6, 1])
    with left, st.container(border=True):
        card_title("Distance Distribution by Stop", "Comparative leg distance across key stops")
        if not stops:
            st.caption("No itinerary stops registered yet.")
        top = sorted(stops, key=lambda s: -s["distance"])[:7]
        peak = max((s["distance"] for s in top), default=1)
        for s in top:
            label = f"#{s['sequence']} {s['name']}"
            label = label if len(label) <= 18 else label[:17] + "…"
            c = st.columns([2.2, 5, 1], vertical_alignment="center")
            c[0].markdown(esc(label))
            c[1].progress(min(1.0, s["distance"] / peak))
            c[2].markdown(f":blue[**{s['distance']:.0f} km**]")
    with right, st.container(border=True):
        card_title("Category Breakdown & Footprint", "Destination composition and resource telemetry")
        total = summary["total_stops"]
        for cat in L.CATEGORIES:
            count = summary["categories"].get(cat, 0)
            pct = f"{count / total * 100:.0f}" if total else "0"
            c = st.columns([1, 1.4], vertical_alignment="center")
            c[0].markdown(cat_badge(cat))
            c[1].markdown(f":gray[{count} stops ({pct}%)]")
        with st.container(border=True):
            st.caption("**LOGISTICS TELEMETRY**")
            c = st.columns([2.2, 1.2])
            c[0].caption("Est. Fuel Consumption (8.5L/100km):")
            c[1].markdown(f"**{summary['fuel']:.1f} Liters**")
            c = st.columns([2.2, 1.2])
            c[0].caption("Est. Carbon Footprint (2.3kg CO2/L):")
            c[1].markdown(f"**{summary['carbon']:.1f} kg CO2**")

    with st.container(border=True):
        c1, c2 = st.columns([4, 1.2], vertical_alignment="center")
        with c1:
            card_title("Upcoming Itinerary Stops", "Next sequentially arranged checkpoints")
        c2.button(f"View All {len(stops)} Stops →", key="dash_viewall", on_click=state.goto,
                  args=("directory",), **BTN)
        w = [0.6, 2.2, 1.5, 1.4, 1.2, 1.5, 1.5, 2.6]
        header_row(w, ["Seq", "Destination", "Category", "Leg Distance", "Leg Time",
                       "Implied Speed", "Cumulative KM", "Status"])
        st.divider()
        for item in L.compute_timeline(stops)[:6]:
            c = st.columns(w, vertical_alignment="center")
            c[0].markdown(f"**#{item['sequence']}**")
            c[1].markdown(f"**{esc(item['name'])}**")
            c[2].markdown(cat_badge(item["category"]))
            c[3].markdown(f"{item['distance']:.1f} km")
            c[4].markdown(f"{item['time']:.1f} hrs")
            c[5].markdown(f"{item['eval']['speed']:.1f} km/h")
            c[6].markdown(f":blue[{item['cum_km']:.1f} km]")
            c[7].markdown(status_badge(item["eval"], "Normal"))
        if not stops:
            st.caption("No stops arranged.")


# --------------------------------------------------------------------------- #
# 2. Arrange itinerary
# --------------------------------------------------------------------------- #
def sequencer(summary: dict) -> None:
    stops = st.session_state.stops
    with st.container(border=True):
        c1, c2, c3, c4 = st.columns([3, 1.5, 1.2, 1.1], vertical_alignment="center")
        with c1:
            card_title("Core Stop Arrangement Engine",
                       "Reorder stops, calculate cumulative transit, and optimize driving efficiency")
        if c2.button("Auto-Optimize Sequence", icon=":material/auto_awesome:", key="seq_opt", **BTN):
            state.optimize_route()
            st.rerun()
        if c3.button("Reverse Route", icon=":material/swap_horiz:", key="seq_rev", **BTN):
            state.reverse_route()
            st.rerun()
        if c4.button("Reset Order", icon=":material/restart_alt:", key="seq_reset", **BTN):
            state.reset_order()
            st.rerun()

        with st.container(border=True):
            st.markdown("**Use ▲ ▼ to arrange sequence:** Cumulative distance and cumulative driving "
                        "times update instantly. Rest stop alerts trigger after 4.5 hours of driving.")
            dep = st.time_input("Departure Time", value=dtime(8, 0), step=300, key="departure")

        timeline = L.compute_timeline(stops, dep.strftime("%H:%M"))
        if not timeline:
            st.info("No stops in itinerary. Click '+ Add Stop' above to begin planning your route.")
        for idx, item in enumerate(timeline):
            ev = item["eval"]
            with st.container(border=True):
                c = st.columns([0.7, 8, 0.55, 0.55, 0.55, 0.55], vertical_alignment="center")
                c[0].markdown(f":blue-background[ **#{item['sequence']}** ]")
                head = f"**{esc(item['name'])}** {cat_badge(item['category'])}"
                if ev["has_warnings"]:
                    head += " " + status_badge(ev)
                with c[1]:
                    st.markdown(head)
                    st.markdown(
                        f":gray[Leg Distance:] **{item['distance']:.1f} km** &nbsp; "
                        f":gray[Driving Duration:] **{item['time']:.1f} hrs** &nbsp; "
                        f":gray[Calculated Pace:] **{ev['speed']:.1f} km/h** &nbsp; "
                        f":gray[Cumulative:] :blue[**{item['cum_km']:.1f} km • {item['cum_h']:.1f}h**]")
                    st.markdown(f":gray[Est. Arrival:] **{item['arrival']}**")
                    if item["notes"]:
                        st.caption(f"“{item['notes']}”")
                c[2].button("▲", key=f"up_{item['id']}", disabled=idx == 0, help="Move Up (Earlier Stop)",
                            on_click=state.move_stop, args=(idx, idx - 1))
                c[3].button("▼", key=f"down_{item['id']}", disabled=idx == len(timeline) - 1,
                            help="Move Down (Later Stop)", on_click=state.move_stop, args=(idx, idx + 1))
                if c[4].button("✎", key=f"seq_edit_{item['id']}", help="Edit Stop Details"):
                    dialogs.edit_stop_dialog(item["id"])
                if c[5].button("✕", key=f"seq_del_{item['id']}", help="Delete Stop"):
                    dialogs.delete_stop_dialog(item["id"])


# --------------------------------------------------------------------------- #
# 3. Records & query
# --------------------------------------------------------------------------- #
DIST_OPTS = {"ALL": "All Distances", "SHORT": "< 200 km (Short)", "MEDIUM": "200 - 700 km (Medium)",
             "LONG": "> 700 km (Long-haul)"}
STATUS_OPTS = {"ALL": "All Statuses", "WARNINGS": "Warnings Only", "NORMAL": "Normal Only"}
SORT_OPTS = {"SEQ_ASC": "Sequence (#1 to #35)", "DIST_DESC": "Distance (High → Low)",
             "DIST_ASC": "Distance (Low → High)", "TIME_DESC": "Travel Time (Longest)",
             "NAME_ASC": "Name (A → Z)"}


def _reset_page() -> None:
    st.session_state.rec_page = 1


def _set_page(value) -> None:
    st.session_state.rec_page = max(1, value)


def directory(summary: dict) -> None:
    ss = st.session_state
    stops = ss.stops

    with st.container(border=True):
        c1, c2 = st.columns([3, 1], vertical_alignment="bottom")
        with c1:
            card_title("Stop Records Directory & Query Filter",
                       "Defensive search, multi-category filtering, and tabular pagination")
        count_slot = c2.empty()

        f = st.columns([3.4, 1.5, 1.7, 1.5, 2], vertical_alignment="center")
        search = f[0].text_input("Search", placeholder="Search by destination name or notes...",
                                 icon=":material/search:", label_visibility="collapsed",
                                 key="rec_search", on_change=_reset_page).strip().lower()
        cat_f = f[1].selectbox("Category", ["ALL"] + L.CATEGORIES, key="rec_cat", on_change=_reset_page,
                               format_func=lambda v: "All Categories" if v == "ALL" else v,
                               label_visibility="collapsed")
        dist_f = f[2].selectbox("Distance", list(DIST_OPTS), key="rec_dist", on_change=_reset_page,
                                format_func=DIST_OPTS.get, label_visibility="collapsed")
        stat_f = f[3].selectbox("Status", list(STATUS_OPTS), key="rec_status", on_change=_reset_page,
                                format_func=STATUS_OPTS.get, label_visibility="collapsed")
        sort_f = f[4].selectbox("Sort", list(SORT_OPTS), key="rec_sort", on_change=_reset_page,
                                format_func=lambda v: SORT_OPTS[v].replace("#35", f"#{max(len(stops), 1)}"),
                                label_visibility="collapsed")

        def keep(s):
            ev = L.evaluate_stop(s)
            if search and search not in s["name"].lower() and search not in (s["notes"] or "").lower():
                return False
            if cat_f != "ALL" and s["category"] != cat_f:
                return False
            if dist_f == "SHORT" and not s["distance"] < 200:
                return False
            if dist_f == "MEDIUM" and not 200 <= s["distance"] <= 700:
                return False
            if dist_f == "LONG" and not s["distance"] > 700:
                return False
            if stat_f == "WARNINGS" and not ev["has_warnings"]:
                return False
            if stat_f == "NORMAL" and ev["has_warnings"]:
                return False
            return True

        rows = [s for s in stops if keep(s)]
        sorters = {"SEQ_ASC": lambda s: s["sequence"], "DIST_DESC": lambda s: -s["distance"],
                   "DIST_ASC": lambda s: s["distance"], "TIME_DESC": lambda s: -s["time"],
                   "NAME_ASC": lambda s: s["name"].lower()}
        rows.sort(key=sorters[sort_f])
        count_slot.markdown(f":gray[Showing {len(rows)} of {len(stops)} records]")

        size_choice = ss.get("rec_size", "20")
        size = None if size_choice == "All" else int(size_choice)
        pages = max(1, math.ceil(len(rows) / size)) if size else 1
        ss.rec_page = min(max(1, ss.rec_page), pages)
        shown = rows[(ss.rec_page - 1) * size: ss.rec_page * size] if size else rows

        w = [0.6, 2, 1.3, 1.3, 1.2, 1.4, 3, 2.2, 1.7]
        header_row(w, ["Seq", "Destination", "Category", "Distance", "Travel Time", "Implied Speed",
                       "Travel Notes", "Status Flags", "Actions"])
        st.divider()
        if not shown:
            st.caption("No matching records found for this query filter.")
        for s in shown:
            ev = L.evaluate_stop(s)
            c = st.columns(w, vertical_alignment="center")
            c[0].markdown(f"**#{s['sequence']}**")
            c[1].markdown(f"**{esc(s['name'])}**")
            c[2].markdown(cat_badge(s["category"]))
            c[3].markdown(f"{s['distance']:.1f} km")
            c[4].markdown(f"{s['time']:.1f} hrs")
            c[5].markdown(f"{ev['speed']:.1f} km/h")
            note = s["notes"] or "-"
            c[6].markdown(esc(note if len(note) <= 38 else note[:37] + "…"), help=note if len(note) > 38 else None)
            c[7].markdown(status_badge(ev))
            a1, a2 = c[8].columns(2)
            if a1.button("Edit", key=f"rec_edit_{s['id']}"):
                dialogs.edit_stop_dialog(s["id"])
            if a2.button("Delete", key=f"rec_del_{s['id']}"):
                dialogs.delete_stop_dialog(s["id"])

        p = st.columns([1.6, 5, 1, 1.3, 1], vertical_alignment="center")
        p[0].selectbox("Rows per page", ["10", "20", "50", "All"], index=1, key="rec_size",
                       on_change=_reset_page)
        p[2].button("← Prev", key="rec_prev", disabled=ss.rec_page <= 1,
                    on_click=_set_page, args=(ss.rec_page - 1,))
        p[3].markdown(f":gray[Page {ss.rec_page} of {pages}]")
        p[4].button("Next →", key="rec_next", disabled=ss.rec_page >= pages,
                    on_click=_set_page, args=(ss.rec_page + 1,))


# --------------------------------------------------------------------------- #
# 4. Threshold inspector
# --------------------------------------------------------------------------- #
def inspector(summary: dict) -> None:
    warnings = summary["warnings"]
    with st.container(border=True):
        c1, c2 = st.columns([4, 1], vertical_alignment="center")
        with c1:
            card_title("Threshold Warning & Anomaly Inspector",
                       "Automated warning flags highlighting fatigue limits, speed anomalies, and critical breaches")
        n = summary["warning_count"]
        c2.markdown(badge(f"{n} Active Flag{'s' if n != 1 else ''}", "orange" if n else "green"))

        t = st.columns(3)
        t[0].warning("**⚠ Driver Fatigue Threshold**\n\nFlags legs exceeding 4.5 continuous driving hours "
                     "without a planned break.")
        t[1].error("**⚡ Speed Anomaly Threshold**\n\nFlags legs with implied speeds > 115 km/h "
                   "(speeding hazard) or < 15 km/h (unrealistic congestion).")
        t[2].info("**⤮ Endurance Leg Threshold**\n\nFlags single legs > 800 km requiring secondary "
                  "co-drivers or layover.")

        if not warnings:
            st.success("**Itinerary In Safe Operating Thresholds** — All planned stops respect speed "
                       "and fatigue limits. No critical breaches detected.", icon=":material/check_circle:")
            return
        for start in range(0, len(warnings), 3):
            cols = st.columns(3)
            for col, w in zip(cols, warnings[start:start + 3]):
                critical = w["severity"] == "critical"
                with col, st.container(border=True):
                    h = st.columns([3, 1.2], vertical_alignment="center")
                    h[0].markdown(badge(f"Stop #{w['stop_seq']}: {w['stop_name']}",
                                        "red" if critical else "orange"))
                    h[1].markdown(badge(w["severity"].upper(), "red" if critical else "orange"))
                    st.markdown(f"**⚠ {w['title']}**")
                    st.caption(w["desc"])
                    st.markdown(f"> **Advisory:** {w['recommendation']}")


# --------------------------------------------------------------------------- #
# 5. Terminal console
# --------------------------------------------------------------------------- #
def terminal(summary: dict) -> None:
    ss = st.session_state
    with st.container(border=True):
        h = st.columns([6, 1])
        h[0].caption("🔴 🟡 🟢   roadtrip-cli • Interactive Terminal Prompt (Python/POSIX Emulated)")
        h[1].caption("v2.4.0")
        recent = ss.term_lines[-22:]
        st.code("\n".join(recent) if recent else " ", language=None)
        if len(ss.term_lines) > 22:
            st.caption(f"Showing the last 22 of {len(ss.term_lines)} lines.")

        with st.form("terminal_form", clear_on_submit=True, border=False):
            c = st.columns([5, 1], vertical_alignment="bottom")
            cmd = c[0].text_input(
                "roadtrip>", label_visibility="collapsed", key="term_input",
                placeholder="roadtrip>  Type a command (e.g. 'list', 'summary', 'warnings', 'add', 'export csv')...")
            go = c[1].form_submit_button("Execute", **stretch(st.form_submit_button))
        if go and cmd.strip():
            state.run_command(cmd)
            st.rerun()

    pending = ss.get("pending_download")
    if pending:
        st.download_button(f"Download {pending['filename']}", data=pending["data"],
                           file_name=pending["filename"], mime=pending["mime"], type="primary",
                           icon=":material/download:", key="term_dl",
                           on_click=state.record_export, args=(pending["kind"],))


# --------------------------------------------------------------------------- #
# Router
# --------------------------------------------------------------------------- #
PAGE_FUNCS = {"dashboard": dashboard, "sequencer": sequencer, "directory": directory,
              "inspector": inspector, "terminal": terminal}


def render_app() -> None:
    summary = L.compute_summary(st.session_state.stops)
    sidebar(summary)
    topbar()
    alert_banner(summary)
    PAGE_FUNCS[st.session_state.page](summary)
