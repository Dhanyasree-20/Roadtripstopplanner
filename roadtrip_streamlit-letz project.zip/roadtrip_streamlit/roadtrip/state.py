"""Session state, persistence, audit log and every action that changes the itinerary."""
from __future__ import annotations

import copy
import json
import re
from pathlib import Path

import streamlit as st

from . import logic as L

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
STATE_FILE = DATA_DIR / "state.json"

PAGES = {
    "dashboard": ("Executive Summary", "Executive Summary & Analytics"),
    "sequencer": ("Arrange Itinerary", "Core Stop Arrangement Engine"),
    "directory": ("Records & Query", "Stop Records Directory & Query Filter"),
    "inspector": ("Threshold Inspector", "Threshold Warning & Anomaly Inspector"),
    "terminal": ("Terminal Console", "Interactive Terminal Prompt"),
}

TERMINAL_BANNER = [
    "=" * 63,
    " ROAD TRIP STOP PLANNER - INTERACTIVE TERMINAL INTERFACE",
    " Project #60 | LocalImpact Challenge | Domain: Travel & Transport",
    "=" * 63,
    "Type 'help' to view all available commands.",
    "Session initialized. 35 pre-seeded test records loaded with defensive schemas.",
    "-" * 63,
]


# --------------------------------------------------------------------------- #
# Loading / saving
# --------------------------------------------------------------------------- #
def default_stops() -> list[dict]:
    with open(DATA_DIR / "sample_data.json", encoding="utf-8") as fh:
        data = json.load(fh)
    stops = copy.deepcopy(data)
    L.reindex(stops)
    return stops


def _normalise(raw: list[dict]) -> list[dict]:
    out = []
    for idx, item in enumerate(raw):
        out.append({
            "id": int(item.get("id") or idx + 1),
            "sequence": int(item.get("sequence") or idx + 1),
            "name": str(item.get("name") or "Waypoint").strip(),
            "distance": max(0.1, float(item.get("distance") or 10)),
            "time": max(0.1, float(item.get("time") or 0.5)),
            "category": item.get("category") if item.get("category") in L.CATEGORIES else "Other",
            "notes": str(item.get("notes") or "").strip(),
            "date": item.get("date") or L.today_iso(),
        })
    out.sort(key=lambda s: s["sequence"])
    L.reindex(out)
    return out


def _load_from_disk():
    try:
        payload = json.loads(STATE_FILE.read_text(encoding="utf-8"))
        stops = _normalise(payload["stops"])
        if not stops:
            raise ValueError("empty")
        return stops, list(payload.get("audit", []))[:200]
    except Exception:
        return None, []


def persist() -> None:
    """Write the itinerary and audit trail to data/state.json (best effort)."""
    try:
        DATA_DIR.mkdir(exist_ok=True)
        STATE_FILE.write_text(json.dumps(
            {"stops": st.session_state.stops, "audit": st.session_state.audit}, indent=2),
            encoding="utf-8")
    except OSError:
        pass


def init_state() -> None:
    ss = st.session_state
    if "stops" in ss:
        return
    stops, audit = _load_from_disk()
    ss.audit = audit
    if stops is None:
        stops = default_stops()
        ss.stops = stops
        log("INITIALIZE_DEFAULT", "Loaded standard 35 sample records")
    else:
        ss.stops = stops
    ss.user = None
    ss.page = "dashboard"
    ss.toasts = []
    ss.term_lines = list(TERMINAL_BANNER)
    ss.pending_download = None
    ss.import_result = None
    ss.setdefault("rec_page", 1)


# --------------------------------------------------------------------------- #
# Audit log, toasts
# --------------------------------------------------------------------------- #
def log(action: str, details: str) -> None:
    audit = st.session_state.audit
    audit.insert(0, {"timestamp": L.now_iso(), "action": action, "details": details})
    del audit[200:]


def toast(msg: str, kind: str = "info") -> None:
    st.session_state.toasts.append((msg, kind))


def flush_toasts() -> None:
    icons = {"success": "✅", "error": "⛔", "warning": "⚠️", "info": "ℹ️"}
    queue, st.session_state.toasts = st.session_state.toasts, []
    for msg, kind in queue:
        st.toast(msg, icon=icons.get(kind, "ℹ️"))


def username() -> str:
    user = st.session_state.get("user")
    return (user or {}).get("username") or "Lead Explorer"


def goto(page: str) -> None:
    st.session_state.page = page


# --------------------------------------------------------------------------- #
# Itinerary actions
# --------------------------------------------------------------------------- #
def _commit(action: str, details: str) -> None:
    L.reindex(st.session_state.stops)
    log(action, details)
    persist()


def add_stop(name, distance, time, category, notes, via="UI") -> dict:
    stops = st.session_state.stops
    stop = {"id": L.next_id(stops), "sequence": len(stops) + 1, "name": name.strip(),
            "distance": float(distance), "time": float(time), "category": category,
            "notes": (notes or "").strip(), "date": L.today_iso()}
    stops.append(stop)
    _commit("ADD_STOP_CLI" if via == "CLI" else "ADD_STOP",
            f"Added '{stop['name']}' via terminal command." if via == "CLI"
            else f"Added '{stop['name']}' ({L.fmt_num(stop['distance'])} km, {L.fmt_num(stop['time'])}h).")
    return stop


def update_stop(stop_id, name, distance, time, category, notes) -> None:
    for s in st.session_state.stops:
        if s["id"] == stop_id:
            s.update(name=name.strip(), distance=float(distance), time=float(time),
                     category=category, notes=(notes or "").strip())
            _commit("EDIT_STOP", f"Updated '{s['name']}'.")
            return


def delete_stop(stop_id) -> None:
    stops = st.session_state.stops
    for i, s in enumerate(stops):
        if s["id"] == stop_id:
            removed = stops.pop(i)
            _commit("DELETE_STOP", f"Removed '{removed['name']}'.")
            toast(f"Removed '{removed['name']}' from the itinerary.", "info")
            return


def move_stop(src: int, dst: int) -> bool:
    stops = st.session_state.stops
    if not (0 <= src < len(stops) and 0 <= dst < len(stops)):
        return False
    item = stops.pop(src)
    stops.insert(dst, item)
    _commit("REORDER_STOP", f"Moved '{item['name']}' from sequence #{src + 1} to #{dst + 1}")
    toast(f"Reordered '{item['name']}' to sequence #{dst + 1}", "info")
    return True


def reverse_route() -> None:
    st.session_state.stops.reverse()
    _commit("REVERSE_ITINERARY", "Inverted entire route sequence.")
    toast("Route itinerary reversed successfully!", "info")


def reset_order() -> None:
    st.session_state.stops.sort(key=lambda s: s["id"])
    _commit("RESET_SEQUENCE", "Reset route to baseline order.")
    toast("Route sequence reset to initial registration order.", "info")


def optimize_route() -> bool:
    if len(st.session_state.stops) < 3:
        toast("Need at least 3 stops to perform route optimization.", "warning")
        return False
    st.session_state.stops = L.optimize_order(st.session_state.stops)
    _commit("OPTIMIZE_ROUTE", "Applied Nearest-Neighbor distance optimization heuristic.")
    toast("Route optimized for minimum distance transitions!", "success")
    return True


def restore_defaults(via: str = "UI") -> None:
    st.session_state.stops = default_stops()
    _commit("RESET_DEFAULT_CLI" if via == "CLI" else "RESET_DEFAULT", "Reset dataset to the standard 35 records.")


def ingest_dataset(content: str, is_json: bool, replace: bool) -> None:
    new_list, audit, ok, bad, error = L.ingest(st.session_state.stops, content, is_json, replace)
    if error:
        toast(error, "error" if "JSON" in error else "warning")
        st.session_state.import_result = None
        return
    st.session_state.import_result = {"audit": audit, "ok": ok, "bad": bad}
    if new_list is None:
        toast("Ingestion completed with 0 valid records accepted.", "error")
        return
    st.session_state.stops = new_list
    _commit("BULK_INGEST", f"Processed {len(audit)} rows: {ok} accepted, {bad} rejected. "
                           f"Mode: {'Replace' if replace else 'Append'}")
    toast(f"Bulk Ingestion Complete: {ok} stops added!", "success")


# --------------------------------------------------------------------------- #
# Exports (used by the export dialog and the terminal)
# --------------------------------------------------------------------------- #
EXPORTS = {
    "csv": ("EXPORT_CSV", "Standardized CSV report downloaded successfully!"),
    "md": ("EXPORT_MARKDOWN", "Structured Markdown report downloaded!"),
    "log": ("EXPORT_AUDIT_LOG", "Audit trail log downloaded!"),
    "json": ("EXPORT_JSON", "State backup JSON downloaded!"),
}


def build_export(kind: str):
    ss = st.session_state
    if kind == "csv":
        return L.build_csv(ss.stops)
    if kind == "md":
        return L.build_markdown(ss.stops, username())
    if kind == "log":
        return L.build_audit_log(ss.audit, username())
    return L.build_json(ss.stops, username())


def record_export(kind: str) -> None:
    """Callback for download buttons: audit-log the export."""
    action, message = EXPORTS[kind]
    log(action, f"Exported {kind.upper()} report.")
    persist()
    toast(message, "success")


# --------------------------------------------------------------------------- #
# Terminal engine
# --------------------------------------------------------------------------- #
HELP_LINES = [
    "================ AVAILABLE CLI COMMANDS ================",
    "  help                          Show this command manual",
    "  list [page]                   Display tabular records",
    "  summary                       Output computed telemetry & totals",
    "  warnings                      List automated threshold alerts",
    "  add <name> <km> <hrs> <cat>   Defensively insert new stop",
    "  move <from_seq> <to_seq>      Arrange stops sequence",
    "  optimize                      Auto-arrange by distance heuristic",
    "  reverse                       Reverse itinerary direction",
    "  export <csv|md|log|json>      Download structured export",
    "  search <keyword>              Query stops by name or notes",
    "  clear                         Clear terminal buffer",
    "  reset                         Reset to standard 35 records",
    "========================================================",
]


def run_command(raw: str) -> None:
    raw = raw.strip()
    if not raw:
        return
    ss = st.session_state
    out = ss.term_lines
    out.append(f"roadtrip> {raw}")

    parts = re.findall(r'(?:[^\s"]+|"[^"]*")+', raw)
    cmd = parts[0].lower()
    args = [re.sub(r'^"|"$', "", a) for a in parts[1:]]
    stops = ss.stops

    if cmd in ("help", "?"):
        out.extend(HELP_LINES)

    elif cmd == "summary":
        s = L.compute_summary(stops)
        out += ["--- EXECUTIVE SUMMARY TELEMETRY ---",
                f"  Total Stops:        {s['total_stops']}",
                f"  Total Distance:     {s['total_km']:.1f} km (~ {s['miles']:.1f} miles)",
                f"  Total Driving Time: {s['time_fmt']}",
                f"  Average Leg Dist:   {s['avg_km']:.1f} km",
                f"  Average Speed:      {s['avg_speed']:.1f} km/h",
                f"  Active Alerts:      {s['warning_count']} flags",
                f"  Fuel Consumed:      {s['fuel']:.1f} L",
                f"  CO2 Emissions:      {s['carbon']:.1f} kg"]

    elif cmd == "warnings":
        alerts = L.compute_summary(stops)["warnings"]
        if not alerts:
            out.append("OK: Zero threshold breaches or driver fatigue warnings detected.")
        else:
            out.append(f"Detected {len(alerts)} threshold alerts:")
            for a in alerts:
                out.append(f"  [{a['severity'].upper()}] Stop #{a['stop_seq']} ({a['stop_name']}): "
                           f"{a['title']} - {a['desc']}")

    elif cmd == "list":
        out.append("SEQ | DESTINATION                  | DISTANCE | TIME  | SPEED     | STATUS")
        out.append("----+------------------------------+----------+-------+-----------+-------")
        for row in stops[:25]:
            ev = L.evaluate_stop(row)
            dist = "%.1f km" % row["distance"]
            hrs = "%.1fh" % row["time"]
            spd = "%.1f km/h" % ev["speed"]
            flag = "WARN" if ev["has_warnings"] else "OK"
            out.append("#%02d | %-28s | %8s | %5s | %9s | %s"
                       % (row["sequence"], row["name"][:28], dist, hrs, spd, flag))
        if len(stops) > 25:
            out.append(f"... and {len(stops) - 25} more stops. Use UI Records & Query tab for full pagination.")

    elif cmd == "optimize":
        if optimize_route():
            out.append("SUCCESS: Nearest-Neighbor route optimization applied to itinerary.")
        else:
            out.append("ERROR: Need at least 3 stops to perform route optimization.")

    elif cmd == "reverse":
        reverse_route()
        out.append("SUCCESS: Route itinerary reversed.")

    elif cmd == "move":
        if len(args) < 2:
            out.append("ERROR: Syntax: move <from_sequence> <to_sequence> (e.g. 'move 4 1')")
            return
        try:
            a, b = int(args[0]), int(args[1])
        except ValueError:
            a = b = 0
        if not (1 <= a <= len(stops) and 1 <= b <= len(stops)):
            out.append(f"ERROR: Sequences must be between 1 and {len(stops)}.")
            return
        move_stop(a - 1, b - 1)
        out.append(f"SUCCESS: Moved stop #{a} to #{b}.")

    elif cmd == "add":
        if len(args) < 4:
            out.append("ERROR: Syntax: add <name> <distance_km> <time_hrs> <category> [notes]")
            return
        name, dist, hrs, cat, *notes = args
        errors = L.validate_stop(stops, name, dist, hrs, cat, " ".join(notes))
        if errors:
            out.append(f"VALIDATION ERROR: {'; '.join(errors.values())}")
            return
        new = add_stop(name, dist, hrs, cat, " ".join(notes), via="CLI")
        out.append(f"SUCCESS: Added stop '{new['name']}' (#{new['sequence']}).")

    elif cmd == "export":
        fmt = (args[0] if args else "csv").lower()
        kind = {"csv": "csv", "md": "md", "markdown": "md", "log": "log", "audit": "log", "json": "json"}.get(fmt)
        if not kind:
            out.append("ERROR: Supported export formats: 'csv', 'md', 'log', 'json'")
            return
        filename, data, mime = build_export(kind)
        ss.pending_download = {"kind": kind, "filename": filename, "data": data, "mime": mime}
        out.append(f"SUCCESS: {fmt.upper()} export ready - use the download button below the terminal.")

    elif cmd == "search":
        if not args:
            out.append("ERROR: Syntax: search <keyword>")
            return
        kw = " ".join(args).lower()
        hits = [s for s in stops if kw in s["name"].lower() or kw in s["category"].lower()
                or kw in (s["notes"] or "").lower()]
        out.append(f"Found {len(hits)} matching stop(s):")
        for m in hits:
            out.append(f"  #{m['sequence']} {m['name']} ({m['category']}) - "
                       f"{L.fmt_num(m['distance'])} km, {L.fmt_num(m['time'])}h")

    elif cmd == "clear":
        ss.term_lines = []

    elif cmd == "reset":
        restore_defaults("CLI")
        out.append("SUCCESS: Restored baseline 35-record dataset.")

    else:
        out.append(f"command not found: '{cmd}'. Type 'help' to inspect command reference.")
