"""Small helpers shared by every view (version-compatibility shims + markdown snippets)."""
from __future__ import annotations

import inspect

import streamlit as st

CAT_COLOR = {"City": "blue", "Nature": "green", "Adventure": "yellow", "Beach": "orange", "Other": "violet"}


def _accepts(fn, name: str) -> bool:
    try:
        return name in inspect.signature(fn).parameters
    except (TypeError, ValueError):
        return False


def stretch(fn) -> dict:
    """Full-width keyword for buttons, working across Streamlit versions."""
    if _accepts(fn, "width"):
        return {"width": "stretch"}
    if _accepts(fn, "use_container_width"):
        return {"use_container_width": True}
    return {}


def dialog(title: str, width: str = "medium"):
    """st.dialog that also refreshes the page behind it when dismissed with the X."""
    kwargs = {"width": width}
    if _accepts(st.dialog, "on_dismiss"):
        kwargs["on_dismiss"] = "rerun"
    return st.dialog(title, **kwargs)


def esc(text) -> str:
    """Escape Markdown control characters in user supplied text."""
    out = str(text)
    for ch in ("\\", "*", "_", "[", "]", "`", "$", "|", "~", "<", ">", "#"):
        out = out.replace(ch, "\\" + ch)
    return out


def badge(text, color="blue", icon=None) -> str:
    label = f":material/{icon}: {esc(text)}" if icon else esc(text)
    return f":{color}-badge[{label}]"


def cat_badge(category: str) -> str:
    return badge(category, CAT_COLOR.get(category, "gray"))


def status_badge(ev: dict, healthy_label: str = "Healthy") -> str:
    if ev["has_warnings"]:
        return badge(ev["flags"][0]["title"], "red" if ev["has_critical"] else "orange", "warning")
    return badge(healthy_label, "green", "check")


def header_row(weights, labels):
    cols = st.columns(weights)
    for col, label in zip(cols, labels):
        col.markdown(f"**{label}**")


def card_title(title: str, subtitle: str = "") -> None:
    st.markdown(f"#### {title}")
    if subtitle:
        st.caption(subtitle)


def stat_card(label: str, value: str, unit: str, hint: str, icon: str) -> None:
    with st.container(border=True):
        top = st.columns([4, 1])
        top[0].caption(f"**{label.upper()}**")
        top[1].markdown(f":blue[:material/{icon}:]")
        st.markdown(f"### {value} :gray[{unit}]" if unit else f"### {value}")
        st.caption(hint)
