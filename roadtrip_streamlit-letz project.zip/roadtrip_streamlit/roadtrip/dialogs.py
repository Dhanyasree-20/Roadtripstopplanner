"""Modal dialogs: add/edit stop, delete confirmation, bulk import, export."""
from __future__ import annotations

import streamlit as st

from . import logic as L
from . import state
from .ui import dialog, esc, stretch


# --------------------------------------------------------------------------- #
# Add / edit
# --------------------------------------------------------------------------- #
def _stop_form(stop: dict | None) -> None:
    ss = st.session_state
    editing = stop is not None
    k = f"edit{stop['id']}" if editing else "add"

    name = st.text_input("Destination Name *", value=stop["name"] if editing else "",
                         placeholder="e.g. Hampi Boulder Trails", key=f"{k}_name")
    c1, c2 = st.columns(2)
    dist = c1.number_input("Distance (KM) *", value=stop["distance"] if editing else None,
                           step=10.0, format="%g", placeholder="e.g. 350", key=f"{k}_dist")
    hrs = c2.number_input("Travel Time (Hours) *", value=stop["time"] if editing else None,
                          step=0.5, format="%g", placeholder="e.g. 6", key=f"{k}_time")

    text, color = L.pace_preview(dist, hrs) if dist is not None and hrs is not None else ("-- km/h", "gray")
    with st.container(border=True):
        st.markdown(f":gray[Calculated Pace:]  :{color}[**{text}**]")

    cat_idx = L.CATEGORIES.index(stop["category"]) if editing else 0
    category = st.selectbox("Category *", L.CATEGORIES, index=cat_idx, key=f"{k}_cat")
    notes = st.text_area("Travel Notes & Waypoints", value=stop["notes"] if editing else "",
                         max_chars=300, height=100, key=f"{k}_notes")

    st.divider()
    _, b_cancel, b_save = st.columns([3, 1.2, 1.8])
    if b_cancel.button("Cancel", key=f"{k}_cancel", **stretch(st.button)):
        st.rerun()
    if b_save.button("Save Stop Entry", type="primary", key=f"{k}_save", **stretch(st.button)):
        errors = L.validate_stop(ss.stops, name, dist, hrs, category, notes,
                                 stop["id"] if editing else None)
        if errors:
            for msg in errors.values():
                st.error(msg)
            return
        if editing:
            state.update_stop(stop["id"], name, dist, hrs, category, notes)
            state.toast(f"Updated '{name.strip()}'.", "success")
        else:
            new = state.add_stop(name, dist, hrs, category, notes)
            state.toast(f"Added '{new['name']}' as stop #{new['sequence']}.", "success")
        st.rerun()


@dialog("Add New Itinerary Stop")
def add_stop_dialog() -> None:
    _stop_form(None)


@dialog("Edit Itinerary Stop")
def edit_stop_dialog(stop_id: int) -> None:
    stop = next((s for s in st.session_state.stops if s["id"] == stop_id), None)
    if stop is None:
        st.warning("That stop no longer exists.")
        return
    _stop_form(stop)


@dialog("Remove Stop", "small")
def delete_stop_dialog(stop_id: int) -> None:
    stop = next((s for s in st.session_state.stops if s["id"] == stop_id), None)
    if stop is None:
        st.warning("That stop no longer exists.")
        return
    st.write(f"Are you sure you want to remove '{stop['name']}' from the itinerary?")
    c1, c2 = st.columns(2)
    if c1.button("Cancel", key=f"delno_{stop_id}", **stretch(st.button)):
        st.rerun()
    if c2.button("Remove", type="primary", key=f"delyes_{stop_id}", **stretch(st.button)):
        state.delete_stop(stop_id)
        st.rerun()


# --------------------------------------------------------------------------- #
# Bulk import
# --------------------------------------------------------------------------- #
def open_import() -> None:
    st.session_state.import_result = None
    st.session_state.import_sig = None
    import_dialog()


@dialog("Bulk Dataset Import with Validation Log", "large")
def import_dialog() -> None:
    ss = st.session_state
    st.caption("Ingest legacy CSV or JSON files with automated schema verification and "
               "detailed row-by-row error auditing.")
    upload = st.file_uploader("Click to browse or drop CSV/JSON file here", type=["csv", "json"],
                              key="import_file")
    st.caption("Standard headers supported: Destination, Distance_KM, Travel_Time_Hours, Category, Notes")

    c1, c2 = st.columns([3, 2], vertical_alignment="center")
    replace = c1.checkbox("Replace current itinerary (Uncheck to append)", key="import_replace")
    if c2.button("Load Standard 35-Entry Sample CSV", key="import_sample", **stretch(st.button)):
        text = (state.DATA_DIR / "sample_data.csv").read_text(encoding="utf-8")
        state.ingest_dataset(text, False, replace)

    if upload is not None:
        sig = (upload.name, upload.size, getattr(upload, "file_id", None))
        if ss.get("import_sig") != sig:
            ss.import_sig = sig
            content = upload.getvalue().decode("utf-8-sig", errors="replace")
            state.ingest_dataset(content, upload.name.lower().endswith(".json"), replace)
    else:
        ss.import_sig = None

    result = ss.get("import_result")
    if result:
        head = st.columns([3, 2], vertical_alignment="center")
        head[0].markdown("**Row-by-Row Validation Audit:**")
        label = f"{result['ok']} Accepted • {result['bad']} Rejected"
        head[1].markdown(f":{'orange' if result['bad'] else 'green'}-badge[{label}]")
        lines = ["| Row # | Destination | Validation Result | Notes |", "| :-- | :-- | :-- | :-- |"]
        for r in result["audit"]:
            if r["ok"]:
                lines.append(f"| **#{r['row']}** | {esc(r['name'])} | :green-badge[PASS] | :gray[{esc(r['note'])}] |")
            else:
                lines.append(f"| :red[**#{r['row']}**] | {esc(r['name'])} | :red-badge[REJECTED] | :red[{esc(r['note'])}] |")
        with st.container(height=320, border=True):
            st.markdown("\n".join(lines))

    st.divider()
    _, close = st.columns([5, 1])
    if close.button("Close", key="import_close", **stretch(st.button)):
        st.rerun()


# --------------------------------------------------------------------------- #
# Export
# --------------------------------------------------------------------------- #
@dialog("Multi-Format Report Export")
def export_dialog() -> None:
    st.caption("Generate standardized reports formatted for external audit, peer evaluation, "
               "and archive storage.")
    cards = [
        ("csv", "Standardized CSV", "Spreadsheet-ready table with formula injection defense.",
         "Download CSV", "primary"),
        ("md", "Structured Markdown", "GitHub flavored markdown with summary blocks and flags.",
         "Download .MD", "secondary"),
        ("log", "Plain-Text Audit Log", "Timestamped history of all session actions and calculations.",
         "Download Log", "secondary"),
        ("json", "State Backup JSON", "Full serialized dataset for offline state restoration.",
         "Download JSON", "secondary"),
    ]
    for row in (cards[:2], cards[2:]):
        cols = st.columns(2)
        for col, (kind, title, desc, label, kind_style) in zip(cols, row):
            with col, st.container(border=True):
                st.markdown(f"**{title}**")
                st.caption(desc)
                filename, data, mime = state.build_export(kind)
                st.download_button(label, data=data, file_name=filename, mime=mime,
                                   type=kind_style, key=f"dl_{kind}",
                                   on_click=state.record_export, args=(kind,),
                                   **stretch(st.download_button))
    st.divider()
    _, close = st.columns([5, 1])
    if close.button("Close", key="export_close", **stretch(st.button)):
        st.rerun()
