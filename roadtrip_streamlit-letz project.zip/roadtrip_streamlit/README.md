# Road Trip Stop Planner — pure Python + Streamlit

The whole app is written in Python with native Streamlit widgets.
There are **no HTML, CSS or JavaScript files** and no `unsafe_allow_html`.
The dark look comes from `.streamlit/config.toml` (Streamlit's own theme settings).

## Run

Windows: double-click `run_streamlit.bat`.

Anywhere:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Needs Python 3.9+ and Streamlit 1.46 or newer.

Sign in with any username/email and a password of 4+ characters, or press **One-Click Demo**
(`explorer@roadtrip.com` / `roadtrip2026`). Like the original site, there is no real account database.

## What is included

| Screen | Screenshot |
|---|---|
| Login (+ validation) | 01, 01b, 11 |
| Executive Summary | 02 |
| Records & Query (search, 4 filters, pagination, edit/delete) | 03 |
| Threshold Inspector | 04 |
| Arrange Itinerary (▲▼ reorder, optimize, reverse, reset, departure time) | 05, 06 |
| Add / Edit stop dialog with live pace + validation | 07 |
| Bulk Import dialog with row-by-row audit | 08 |
| Export dialog (CSV, Markdown, Audit Log, JSON) | 09 |
| Terminal Console (help, list, summary, warnings, add, move, optimize, reverse, export, search, clear, reset) | 10 |

## Files

- `app.py` – entry point
- `roadtrip/logic.py` – validation, thresholds, timeline, summary, optimizer, exports, import (no Streamlit)
- `roadtrip/state.py` – session state, saving, audit log, itinerary actions, terminal engine
- `roadtrip/views.py` – sidebar, top bar and the five pages
- `roadtrip/dialogs.py` – add/edit/delete, import, export dialogs
- `roadtrip/auth.py` – login screen
- `data/sample_data.*` – the 35 sample stops
- `data/state.json` – created automatically; your itinerary and audit trail. Delete it to start fresh.

## Differences from the old HTML version (Streamlit limits)

- No drag-and-drop reordering; use ▲ ▼ (the info box says so).
- The page background gradient, glow effects and coloured left borders on warning rows can't be done without CSS.
- Category colours use Streamlit's palette (City blue, Nature green, Adventure yellow, Beach orange, Other violet).
- Terminal `export` prepares the file and shows a download button under the terminal.
- Data is saved to `data/state.json` on the server instead of browser localStorage, so it is shared by anyone using the same running app.
