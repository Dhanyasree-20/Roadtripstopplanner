"""Road Trip Stop Planner - pure Python / Streamlit.

Run with:  python -m streamlit run app.py
"""
import streamlit as st

st.set_page_config(page_title="Road Trip Stop Planner", page_icon="🚗", layout="wide")

from roadtrip import auth, state, views  # noqa: E402  (must come after set_page_config)

state.init_state()
state.flush_toasts()

if st.session_state.user is None:
    auth.login_view()
else:
    views.render_app()
